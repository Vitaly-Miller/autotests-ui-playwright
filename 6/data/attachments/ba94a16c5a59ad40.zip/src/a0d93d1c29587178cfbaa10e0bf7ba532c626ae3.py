"""
Browsers fixtures
"""
import pytest
from playwright.sync_api import Playwright, StorageState

from config import settings
from tools.playwright.init_page import init_playwright_page  # helper
from tools.registration import registration_new_user  # helper


#=======================================================================================================================
# Guest page
@pytest.fixture(params=settings.browser)
def page_guest(playwright: Playwright, request: pytest.FixtureRequest):
    """
    Fixture GUEST-Page for authentication (NO Storage state)

    :param playwright: Playwright
    :param request: pytest.FixtureRequest (test name for tracing + request.param for browser parametrization)
    :return: yield from - Page from init_playwright_page() without Storage state
    """
    yield from init_playwright_page(
        playwright=playwright,
        test_name=request.node.name,
        browser_engine=request.param
    )

# Page with Storage state 📦
@pytest.fixture(params=settings.browser)
def page(playwright: Playwright, request: pytest.FixtureRequest, storage_state: StorageState):
    """
    Fixture Page + Storage state for authorized user (registered)

    :param playwright: Playwright
    :param storage_state: Фикстура с сохраненными авторизационными данными
    :param request: pytest.FixtureRequest (test name for tracing + request.param for browser parametrization)
    :return: yield from - Page from init_playwright_page() with Storage state
    """
    yield from init_playwright_page(
        playwright=playwright,
        test_name=request.node.name,
        storage_state=storage_state,
        browser_engine=request.param
    )


#-----------------------------------------------------------------------------------------------------------------------
# Storage state 📦
@pytest.fixture(scope='session')                # Выполняется один раз за всю тестовую сессию
def storage_state(playwright: Playwright):      # Используем встроенную фикстуру playwright из pytest_playwright plugin
    """
    Фикстура для внутреннего использования, сохраняющая storage_state c авторизационными данными

    :param playwright: Playwright
    :return: yield - StorageState / storage_state.json
    """
    browser = playwright.chromium.launch()      # Создаем объект браузера на движке
    context = browser.new_context(base_url=settings.base_url)   # Создание браузерного окружения
    page = context.new_page()                                   # Создаем объект страницы page на базе context
    registration_new_user(page)                                 # Registration new user (helper)
    page.wait_for_function(                                     # ❗ ждем user, иначе Storage state будет пустым
        expression='email => localStorage.getItem("persist:users")?.includes(email)',
        arg=settings.test_user.email
    )
    storage_state = context.storage_state()                     # v.1 - Storage state в переменную
    # context.storage_state(path=Dir.STORAGE_STATE_FILE)                  # v.2 - Storage state в 💾 JSON-файл  (optional)
    # storage_state = context.storage_state(path=Dir.STORAGE_STATE_FILE)  # v.3 - Storage state в переменную + 💾 JSON-файл  (optional)
    try:
        yield storage_state                     # Передаем Storage state

    finally:                                    # Гарантия закрытия, если упадет.
        context.close()                         # Закрываем context!
        browser.close()                         # Закрываем browser!


#-------------------------------------------------------- OPTIONAL -----------------------------------------------------
# Custom selector (NOT USING)
# @pytest.fixture(scope='session', autouse=True)
# def selector_id_attribute(playwright: Playwright):
#     """
#     Custom selector identification
#
#     Use if not default in the DOM <data-testid='...'>
#
#     :param playwright: Playwright
#     """
#     playwright.selectors.set_test_id_attribute('qa-id')  # for example
#=======================================================================================================================
