"""
Link element
"""
import allure
from playwright.sync_api import expect

from elements.base_element import BaseElement

#=======================================================================================================================
class Link(BaseElement):
    # href (Hypertext Reference)
    def check_href(self, href: str, nth: int = 0):
        """
        ✔ Check [Link] "href" url-attribute

        :param href: "href" url-attribute
        :param nth: nth-index of locator
        """
        nth_info = self._nth_info(nth)
        step = f'✔ Check {self.name}{nth_info} "href": "{href}"'
        error = f'{self.error}{nth_info} - incorrect "href" url-attribute!'
        with allure.step(step):
            self.logger.info(step)
            expect(self.locator.nth(nth), error).to_have_attribute('href', href)


#=======================================================================================================================
